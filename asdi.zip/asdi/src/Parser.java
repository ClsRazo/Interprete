public interface Parser {
    boolean parse();
}
